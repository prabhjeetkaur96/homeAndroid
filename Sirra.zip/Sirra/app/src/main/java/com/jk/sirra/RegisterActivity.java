package com.jk.sirra;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnRegister;
    EditText edtName;
    EditText edtPhone;
    EditText edtEmail;
    EditText edtPassword;
    TextView txtDOB;

    DBHelper dbHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnRegister = findViewById(R.id.btnRegister);
        edtName = findViewById(R.id.edtName);
        edtPhone = findViewById(R.id.edtPhone);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        txtDOB = findViewById(R.id.txtDOB);
        txtDOB.setOnClickListener(this);

        btnRegister.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnRegister.getId()){
            insertData();
            displayData();

            finish();
            startActivity(new Intent(this,LoginActivity.class));

        }else if(view.getId() == txtDOB.getId()){
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener,
                    calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)).show();
        }
    }

    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            String date = String.valueOf(month+1) + "/" + String.valueOf(day) + "/" + String.valueOf(year);
            txtDOB.setText(date);
        }
    };

    private void insertData(){
        try{
            ContentValues cv = new ContentValues();
            cv.put("Name",edtName.getText().toString());
            cv.put("Phone",edtPhone.getText().toString());
            cv.put("Email",edtEmail.getText().toString());
            cv.put("Password",edtPassword.getText().toString());
            cv.put("DOB",txtDOB.getText().toString());

            sqLiteDatabase = dbHelper.getWritableDatabase();
            sqLiteDatabase.insert("UserInfo", null,cv);

            Log.v("RegisterActivity","User Account Created");

        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally {
            sqLiteDatabase.close();
        }
    }

    private void displayData(){
        try{
            sqLiteDatabase = dbHelper.getReadableDatabase();
            String columns[] = {"Name", "Phone", "Email", "Password","DOB"};

            Cursor cursor = sqLiteDatabase.query("UserInfo",columns,
                    null,null,null, null, null);

            while (cursor.moveToNext()){
                String userData = cursor.getString(cursor.getColumnIndex("Name"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("Phone"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("Email"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("Password"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("DOB"));

                Toast.makeText(this, userData,Toast.LENGTH_LONG).show();
            }

        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally {
            sqLiteDatabase.close();
        }
    }
}












